﻿using System;
using System.Collections.Generic;
using System.Text;

namespace Strazh.Tests.ProjectB.Root.Left.Right
{
    public class Leaf2    {
    }
}
