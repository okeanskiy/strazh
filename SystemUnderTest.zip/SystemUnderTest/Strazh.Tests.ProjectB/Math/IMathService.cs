﻿namespace Strazh.Tests.ProjectB.Math
{
    public interface IMathService
    {
        public int Sum(int a, string b);

        public int Sum(int a, int b);

        public int Sum(int a, int b, int c);
    }
}
