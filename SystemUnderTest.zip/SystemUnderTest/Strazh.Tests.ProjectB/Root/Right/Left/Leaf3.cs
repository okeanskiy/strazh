﻿using System;
using System.Collections.Generic;
using System.Text;

namespace Strazh.Tests.ProjectB.Root.Right.Left
{
    public class Leaf3
    {
    }
}
